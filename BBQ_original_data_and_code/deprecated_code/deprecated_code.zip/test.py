import httpx

API_KEY = 'sk-uIcWCOCDabGWyn4z70Ad81E746304a98922eE7D75050Fd94'
MODEL = 'gpt-3.5-turbo'
URL = 'https://hk.xty.app/v1'
if __name__ == '__main__':
    from openai import OpenAI

    client = OpenAI(
        base_url=URL,
        api_key=API_KEY,
        http_client=httpx.Client(
            base_url=URL,
            follow_redirects=True,
        ),
    )
    completion = client.chat.completions.create(
        model=MODEL,
        messages=[{'role': 'user', 'content': 'Hello.'}],
        temperature=0.7
    )
    print(completion.choices[0].message.content)
